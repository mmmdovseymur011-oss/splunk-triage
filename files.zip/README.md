# splunk-triage

Splunk REST API vasitesile SIEM loglarini toplayan, detection qaydalarini isledən və tapintilari
**risk balina gore prioritetlesdirən** yungul Python aleti (SOC triage).

## Imkanlar
- Splunk `search/jobs/export` ile axinla log cekme (token ve ya user/parol)
- `rules.yml` – SPL esasli detection qaydalari, MITRE ATT&CK xeritesi ile
- Skorlama: `severity_weight * (1 + log10(count))`
- Korrelyasiya: eyni user/host/IP ucun bir nece ferqli qayda tetiklenerse bal x1.5 (ehtimal olunan hucum zenciri)
- Cixis: console cedveli, JSON, Markdown hesabat
- `--demo` rejimi: Splunk olmadan sinaq

## Qurasdirma
```bash
pip install -r requirements.txt
```

## Istifade
```bash
export SPLUNK_URL=https://splunk.example.com:8089
export SPLUNK_TOKEN=<token>

python splunk_triage.py --rules rules.yml --earliest -24h --md report.md --json report.json
```
Sinaq ucun: `python splunk_triage.py --demo --md demo_report.md`

## Oz qaydani elave etmek
`rules.yml`-e yeni element elave edin. SPL sorgusu `entity` (user/host/IP) ve `count` saheleri qaytarmalidir.

## Qeyd
Yalniz oz icazeniz olan Splunk muhitinde istifade edin. Token-i koda yazmayin, mühit deyisenlerinden istifade edin.
