#!/usr/bin/env python3
"""
splunk-triage: Splunk-dan SIEM loglarini toplayir, detection qaydalarini isledir,
tapintilari risk balina gore prioritetlesdirir ve hesabat (console/JSON/Markdown) yaradir.

Istifade:
    export SPLUNK_URL=https://splunk.example.com:8089
    export SPLUNK_TOKEN=<token>
    python splunk_triage.py --rules rules.yml --earliest -24h --md report.md

Splunk olmadan sinaq ucun:
    python splunk_triage.py --demo
"""
import argparse
import datetime as dt
import json
import math
import os
import sys
from collections import defaultdict

import requests
import yaml

requests.packages.urllib3.disable_warnings()

SEVERITY_WEIGHT = {"low": 1, "medium": 3, "high": 6, "critical": 10}


# --------------------------------------------------------------------------- #
# Splunk client
# --------------------------------------------------------------------------- #
class SplunkClient:
    def __init__(self, url, token=None, user=None, password=None, verify=True):
        self.url = url.rstrip("/")
        self.session = requests.Session()
        self.session.verify = verify
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"
        elif user and password:
            self.session.auth = (user, password)
        else:
            raise SystemExit("Auth yoxdur: SPLUNK_TOKEN ve ya SPLUNK_USER/SPLUNK_PASSWORD teyin edin.")

    def search(self, spl, earliest="-24h", latest="now", max_results=1000):
        """Splunk /search/jobs/export endpoint-i ile axinla netice qaytarir."""
        spl = spl.strip()
        if not spl.startswith(("search ", "|")):
            spl = "search " + spl
        resp = self.session.post(
            f"{self.url}/services/search/jobs/export",
            data={
                "search": spl,
                "earliest_time": earliest,
                "latest_time": latest,
                "output_mode": "json",
                "count": max_results,
            },
            stream=True,
            timeout=300,
        )
        resp.raise_for_status()
        rows = []
        for line in resp.iter_lines():
            if not line:
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if "result" in obj and not obj.get("preview"):
                rows.append(obj["result"])
        return rows


# --------------------------------------------------------------------------- #
# Demo data (Splunk olmadan test ucun)
# --------------------------------------------------------------------------- #
DEMO_RESULTS = {
    "win_brute_force": [
        {"entity": "administrator", "count": "87", "src_ips": ["10.10.5.23", "185.220.101.4"]},
        {"entity": "jdoe", "count": "14", "src_ips": ["10.10.5.77"]},
    ],
    "win_success_after_failures": [
        {"entity": "administrator", "count": "52", "successes": "1", "src_ip": "185.220.101.4"},
    ],
    "win_encoded_powershell": [
        {"entity": "WS-FIN-042", "count": "6", "user": "jdoe"},
    ],
    "win_new_admin_member": [
        {"entity": "WS-FIN-042", "count": "1", "user": "backdoor_svc"},
    ],
    "win_log_cleared": [
        {"entity": "WS-FIN-042", "count": "1"},
    ],
    "linux_ssh_brute_force": [
        {"entity": "45.155.205.233", "count": "340"},
    ],
}


# --------------------------------------------------------------------------- #
# Core logic
# --------------------------------------------------------------------------- #
def load_rules(path):
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data["rules"]


def run_rules(rules, client, earliest, latest, demo=False):
    findings = []
    for rule in rules:
        rid = rule["id"]
        try:
            if demo:
                rows = DEMO_RESULTS.get(rid, [])
            else:
                rows = client.search(rule["query"], rule.get("earliest", earliest), latest)
        except Exception as exc:  # noqa: BLE001
            print(f"[!] {rid}: sorgu ugursuz oldu: {exc}", file=sys.stderr)
            continue
        print(f"[+] {rid}: {len(rows)} netice", file=sys.stderr)
        for row in rows:
            try:
                count = int(float(row.get("count", 1)))
            except (TypeError, ValueError):
                count = 1
            findings.append(
                {
                    "rule_id": rid,
                    "rule_name": rule["name"],
                    "severity": rule["severity"],
                    "mitre": rule.get("mitre", ""),
                    "entity": str(row.get("entity", "unknown")),
                    "count": count,
                    "score": SEVERITY_WEIGHT[rule["severity"]] * (1 + math.log10(max(count, 1))),
                    "details": {k: v for k, v in row.items() if k not in ("entity", "count")},
                }
            )
    return findings


def correlate(findings):
    """Eyni entity (user/host/IP) uzre tapintilari birlesdirir.
    2+ ferqli qayda tetiklenibse, ehtimal olunan hucum zenciri kimi bal 1.5x artirilir."""
    groups = defaultdict(list)
    for f in findings:
        groups[f["entity"]].append(f)

    incidents = []
    for entity, items in groups.items():
        total = sum(i["score"] for i in items)
        distinct = len({i["rule_id"] for i in items})
        if distinct >= 2:
            total *= 1.5
        priority = "P1" if total >= 20 else "P2" if total >= 10 else "P3" if total >= 5 else "P4"
        incidents.append(
            {
                "entity": entity,
                "priority": priority,
                "score": round(total, 1),
                "distinct_rules": distinct,
                "findings": sorted(items, key=lambda x: -x["score"]),
            }
        )
    return sorted(incidents, key=lambda x: -x["score"])


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #
def print_console(incidents):
    if not incidents:
        print("Tapinti yoxdur.")
        return
    print(f"\n{'PRIORITY':<9}{'SCORE':<8}{'ENTITY':<24}{'RULES':<7}TOP FINDING")
    print("-" * 90)
    for inc in incidents:
        top = inc["findings"][0]
        print(f"{inc['priority']:<9}{inc['score']:<8}{inc['entity'][:22]:<24}{inc['distinct_rules']:<7}{top['rule_name']}")


def write_markdown(incidents, path, earliest):
    lines = [
        "# Splunk Triage Hesabati",
        f"\nYaradilib: {dt.datetime.now():%Y-%m-%d %H:%M}  |  Zaman araligi: `{earliest}` -> now\n",
        "| Prioritet | Bal | Entity | Qayda sayi |",
        "|---|---|---|---|",
    ]
    for inc in incidents:
        lines.append(f"| {inc['priority']} | {inc['score']} | `{inc['entity']}` | {inc['distinct_rules']} |")
    for inc in incidents:
        lines.append(f"\n## {inc['priority']} - `{inc['entity']}` (bal: {inc['score']})\n")
        for f in inc["findings"]:
            lines.append(
                f"- **{f['rule_name']}** [{f['severity']}] - say: {f['count']} - MITRE: {f['mitre']}  \n"
                f"  Detallar: `{json.dumps(f['details'], ensure_ascii=False)}`"
            )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


# --------------------------------------------------------------------------- #
def main():
    p = argparse.ArgumentParser(description="Splunk SIEM log triage aleti")
    p.add_argument("--rules", default="rules.yml")
    p.add_argument("--earliest", default="-24h")
    p.add_argument("--latest", default="now")
    p.add_argument("--url", default=os.getenv("SPLUNK_URL", "https://localhost:8089"))
    p.add_argument("--insecure", action="store_true", help="TLS sertifikat yoxlamasini sondur")
    p.add_argument("--json", dest="json_out", help="JSON neticeni fayla yaz")
    p.add_argument("--md", dest="md_out", help="Markdown hesabati fayla yaz")
    p.add_argument("--demo", action="store_true", help="Splunk-siz numune data ile isle")
    args = p.parse_args()

    rules = load_rules(args.rules)
    client = None
    if not args.demo:
        client = SplunkClient(
            args.url,
            token=os.getenv("SPLUNK_TOKEN"),
            user=os.getenv("SPLUNK_USER"),
            password=os.getenv("SPLUNK_PASSWORD"),
            verify=not args.insecure,
        )

    findings = run_rules(rules, client, args.earliest, args.latest, demo=args.demo)
    incidents = correlate(findings)
    print_console(incidents)

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump(incidents, fh, indent=2, ensure_ascii=False)
    if args.md_out:
        write_markdown(incidents, args.md_out, args.earliest)
        print(f"\nHesabat yazildi: {args.md_out}")


if __name__ == "__main__":
    main()
